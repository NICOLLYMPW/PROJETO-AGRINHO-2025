let plantas = []; // Array para armazenar todas as plantas no campo
let pontuacao = 0; // Contador de colheitas

const QUANTIDADE_PLANTAS = 20; // Quantidade inicial de plantas no campo

let caminhao; // Variável para o nosso caminhão colheitadeira

// Variável de estado do jogo: 'inicio', 'jogando', 'venceu'
let estadoJogo = 'inicio'; 

function setup() {
  createCanvas(600, 400); // Cria um холst de 600x400 pixels (2D)

  // As plantas e o caminhão não são inicializados aqui,
  // eles serão criados pela função `iniciarJogo()`
}

function draw() {
  background(135, 206, 235); // Cor de fundo: Azul céu

  // Dependendo do estado do jogo, desenha diferentes coisas
  if (estadoJogo === 'inicio') {
    desenharTelaInicio();
  } else if (estadoJogo === 'jogando') {
    // Desenha todos os elementos do jogo
    desenharSol();
    desenharNuvens();
    desenharChao();
    desenharArvore();
    desenharPersonagem();

    // Move e exibe o caminhão, e verifica a colheita
    caminhao.mover();
    caminhao.colherPlantas(plantas);
    caminhao.exibir();
    
    // Verifica se todas as plantas foram colhidas para mudar para o estado 'venceu'
    verificarFimDeJogo();

    // Desenha cada planta (colhidas ou não)
    for (let planta of plantas) {
      planta.exibir();
    }

    mostrarPontuacao(); // Exibe a pontuação
  } else if (estadoJogo === 'venceu') {
    // Se o jogo venceu, exibe a mensagem de vitória E o botão de reiniciar
    exibirMensagemVitoria();

    // Ainda desenha as plantas e a pontuação final para referência,
    // mas elas estarão sob a tela de vitória semi-transparente
    for (let planta of plantas) {
      planta.exibir();
    }
    mostrarPontuacao(); // Mostra a pontuação final por cima da tela de vitória
  }
}

// --- Funções de Desenho do Cenário ---
function desenharSol() {
  fill(255, 204, 0); 
  noStroke();
  ellipse(width - 70, 70, 80, 80);
}

function desenharNuvens() {
  fill(255, 255, 255, 200);
  noStroke();
  ellipse(100, 80, 70, 50);
  ellipse(130, 70, 60, 40);
  ellipse(70, 70, 50, 40);
  ellipse(400, 100, 80, 60);
  ellipse(430, 90, 70, 50);
  ellipse(370, 90, 60, 45);
}

function desenharArvore() {
  fill(139, 69, 19); 
  noStroke();
  rect(width / 4, height / 2 - 50, 30, 100); 
  fill(34, 139, 34); 
  ellipse(width / 4 + 15, height / 2 - 80, 100, 100);
}

function desenharChao() {
  fill(139, 69, 19); 
  noStroke();
  rect(0, height / 2, width, height / 2);
}

function desenharPersonagem() {
  let personagemX = width - 100;
  let personagemY = height - 80;
  fill(210, 180, 140);
  triangle(personagemX - 20, personagemY - 40, personagemX + 40, personagemY - 40, personagemX + 10, personagemY - 60);
  fill(255, 220, 170);
  ellipse(personagemX + 10, personagemY - 30, 30, 30);
  fill(0, 150, 0);
  rect(personagemX, personagemY - 15, 20, 30);
  stroke(0, 150, 0);
  strokeWeight(3);
  line(personagemX, personagemY - 5, personagemX - 10, personagemY + 5);
  line(personagemX + 20, personagemY - 5, personagemX + 30, personagemY + 5);
  line(personagemX + 5, personagemY + 15, personagemX - 5, personagemY + 35);
  line(personagemX + 15, personagemY + 15, personagemX + 25, personagemY + 35);
  noStroke();
}

function mostrarPontuacao() {
  fill(0);
  textSize(24);
  fill(255, 255, 255, 180);
  rect(10, 10, 180, 40, 5);
  fill(0);
  text(`Colheitas: ${pontuacao}`, 20, 35);
}

// --- Função da Tela de Início ---
function desenharTelaInicio() {
  // Fundo
  background(135, 206, 235); // Céu
  desenharChao(); // Terra
  desenharSol();
  desenharNuvens();
  desenharArvore();
  desenharPersonagem();

  // Título do jogo
  fill(0); // Cor do texto
  textSize(48);
  textAlign(CENTER, CENTER);
  text("Agrinho Colheita", width / 2, height / 2 - 80);

  // Botão "Iniciar Jogo"
  desenharBotao("Iniciar Jogo", width / 2, height / 2);
}

// --- Funções de Controle de Jogo ---
function verificarFimDeJogo() {
  let todasColhidas = true;
  for (let planta of plantas) {
    if (!planta.foiColhida) {
      todasColhidas = false;
      break;
    }
  }

  if (todasColhidas) {
    estadoJogo = 'venceu'; // Muda o estado para 'venceu'
  }
}

function exibirMensagemVitoria() {
  // Fundo escuro semi-transparente
  fill(0, 0, 0, 150);
  rect(0, 0, width, height);

  // Texto de vitória
  fill(255, 255, 0); // Amarelo vibrante
  textSize(60);
  textAlign(CENTER, CENTER); // Centraliza o texto
  text("VITÓRIA!", width / 2, height / 2 - 60);

  fill(255); // Branco
  textSize(24);
  text(`Você colheu ${pontuacao} plantas!`, width / 2, height / 2 - 10);

  // Botão "Reiniciar Jogo"
  desenharBotao("Reiniciar Jogo", width / 2, height / 2 + 50);
}

// --- Função Reutilizável para Desenhar Botões ---
function desenharBotao(texto, xCentro, yCentro) {
  let botaoLargura = 200;
  let botaoAltura = 60;
  let botaoX = xCentro - botaoLargura / 2;
  let botaoY = yCentro - botaoAltura / 2;

  fill(50, 200, 50); // Cor verde
  noStroke();
  rect(botaoX, botaoY, botaoLargura, botaoAltura, 10); // Retângulo arredondado

  fill(255); // Cor branca para o texto
  textSize(32);
  textAlign(CENTER, CENTER);
  text(texto, xCentro, yCentro); // Texto centralizado no botão
}


// --- Função mouseClicked (Ajustada para ambos os botões) ---
function mouseClicked() {
  // Coordenadas e dimensões padrão dos botões
  let botaoLargura = 200;
  let botaoAltura = 60;

  if (estadoJogo === 'inicio') {
    let botaoX = width / 2 - botaoLargura / 2;
    let botaoY = height / 2 - botaoAltura / 2; // Y do botão "Iniciar"

    if (mouseX > botaoX && mouseX < botaoX + botaoLargura &&
        mouseY > botaoY && mouseY < botaoY + botaoAltura) {
      iniciarJogo();
    }
  } else if (estadoJogo === 'venceu') {
    let botaoX = width / 2 - botaoLargura / 2;
    let botaoY = height / 2 + 50 - botaoAltura / 2; // Y do botão "Reiniciar"

    if (mouseX > botaoX && mouseX < botaoX + botaoLargura &&
        mouseY > botaoY && mouseY < botaoY + botaoAltura) {
      iniciarJogo(); // A função iniciarJogo() também serve para reiniciar!
    }
  }
}

// --- Função para Iniciar/Reiniciar o Jogo ---
function iniciarJogo() {
  // Reinicia as variáveis do jogo para um novo começo
  plantas = [];
  pontuacao = 0;
  
  // Cria as plantas novamente
  for (let i = 0; i < QUANTIDADE_PLANTAS; i++) {
    let x = random(50, width - 50);
    let y = random(height / 2 + 20, height - 20);
    plantas.push(new Planta(x, y));
  }

  // Cria o caminhão novamente
  caminhao = new Caminhao(width / 2, height - 70);

  estadoJogo = 'jogando'; // Muda o estado para 'jogando'
}


// --- CLASSE CAMINHAO (igual à anterior) ---
class Caminhao {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.largura = 60;
    this.altura = 40;
    this.velocidade = 2.5;
    this.angulo = 0;
  }

  exibir() {
    push();
    translate(this.x, this.y);
    rotate(this.angulo);
    fill(100, 100, 200);
    rect(-this.largura / 2, -this.altura / 2, this.largura, this.altura);
    fill(80, 80, 180);
    rect(this.largura / 2 - 15, -this.altura / 2, 20, this.altura / 2);
    fill(50);
    ellipse(-this.largura / 2 + 10, this.altura / 2, 15, 15);
    ellipse(this.largura / 2 - 10, this.altura / 2, 15, 15);
    pop();
  }

  mover() {
    if (keyIsDown(87)) {
      this.x += cos(this.angulo) * this.velocidade;
      this.y += sin(this.angulo) * this.velocidade;
    }
    if (keyIsDown(83)) {
      this.x -= cos(this.angulo) * this.velocidade * 0.7;
      this.y -= sin(this.angulo) * this.velocidade * 0.7;
    }
    if (keyIsDown(65)) {
      this.angulo -= 0.05;
    }
    if (keyIsDown(68)) {
      this.angulo += 0.05;
    }
    this.x = constrain(this.x, this.largura / 2, width - this.largura / 2);
    this.y = constrain(this.y, height / 2 + this.altura / 2, height - this.altura / 2);
  }

  colherPlantas(plantasArray) {
    for (let i = plantasArray.length - 1; i >= 0; i--) {
      let planta = plantasArray[i];
      if (!planta.foiColhida) {
        let distancia = dist(this.x, this.y, planta.x + planta.largura / 2, planta.y + planta.altura / 2);
        if (distancia < this.largura / 2 + planta.largura / 2 + 10) {
          planta.colher();
          pontuacao++;
        }
      }
    }
  }
}

// --- CLASSE PLANTA (igual à anterior) ---
class Planta {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.largura = 15;
    this.altura = 40;
    this.foiColhida = false;
  }

  exibir() {
    push();
    translate(this.x, this.y);
    if (this.foiColhida) {
      fill(210, 180, 140);
      stroke(150, 120, 90);
    } else {
      fill(100, 150, 50);
      stroke(70, 100, 30);
    }
    strokeWeight(2);
    rect(0, 0, this.largura, this.altura);
    if (!this.foiColhida) {
      fill(255, 200, 0);
      noStroke();
      ellipse(this.largura / 2, -5, this.largura, 10);
    }
    pop();
  }

  colher() {
    this.foiColhida = true;
  }
}